/**
 * @file src/reviewer/render-session.ts
 * @summary Renders the active study-session view including the flashcard UI, grading buttons, MCQ option display, cloze blanks, image-occlusion cards, info panels, skip/undo controls, and the session header. This is the primary rendering entry point for the session mode of the reviewer.
 *
 * @exports
 *   - renderSessionMode — Builds and mounts the full session-mode DOM (card, buttons, header, menus) into the given container
 */

import { Setting } from "obsidian";
import { refreshAOS } from "../core/aos-loader";
import { log } from "../core/logger";
import { setCssProps } from "../core/ui";
import { applyInlineMarkdown } from "../anki/anki-mapper";
import { renderStudySessionHeader } from "./study-session-header";
import type { Scope, Session, Rating } from "./types";
import type { CardRecord } from "../core/store";

declare global {
  interface Window {
    sproutOpenCurrentCardNote?: () => void;
  }
}

type Args = {
  container: HTMLElement;

  session: Session;
  showAnswer: boolean;
  setShowAnswer: (v: boolean) => void;

  currentCard: () => CardRecord | null;

  // navigation
  backToDecks: () => void;
  nextCard: (userInitiated: boolean) => Promise<void> | void;

  // grading
  gradeCurrentRating: (rating: Rating, meta: Record<string, unknown> | null) => Promise<void>;
  answerMcq: (choiceIdx: number) => Promise<void>;

  // skip (session-only postpone; no scheduling changes)
  enableSkipButton?: boolean;
  skipEnabled?: boolean;
  skipCurrentCard: (meta?: Record<string, unknown>) => void;

  // bury / suspend
  canBurySuspend?: boolean;
  buryCurrentCard?: () => void;
  suspendCurrentCard?: () => void;

  // undo
  canUndo?: boolean;
  undoLast?: () => void;

  // practice empty-state (optional)
  practiceMode?: boolean;
  canStartPractice?: boolean;
  startPractice?: () => void;

  // info / countdown
  showInfo: boolean;
  clearTimer: () => void;
  clearCountdown: () => void;
  getNextDueInScope: (scope: Scope) => number | null;
  startCountdown: (nextDue: number, lineEl: HTMLElement) => void;

  // cloze rendering (legacy)
  renderClozeFront: (text: string, reveal: boolean, targetIndex?: number | null) => HTMLElement;

  // markdown rendering
  renderMarkdownInto: (containerEl: HTMLElement, md: string, sourcePath: string) => Promise<void>;

  // ✅ IO rendering hook (provided by reviewer.ts)
  renderImageOcclusionInto?: (
    containerEl: HTMLElement,
    card: CardRecord,
    sourcePath: string,
    reveal: boolean,
  ) => Promise<void>;

  // MCQ option randomisation
  randomizeMcqOptions: boolean;

  // grading mode
  fourButtonMode?: boolean;

  // edit modal
  openEditModal?: () => void;

  // AOS animation control
  applyAOS?: boolean;
  aosDelayMs?: number;

  rerender: () => void;
};

function buildCardAnchorFragment(cardId: string | null | undefined): string {
  const raw = String(cardId ?? "").trim();
  if (!raw) return "";
  const cleaned = raw.startsWith("^") ? raw.slice(1) : raw;
  const normalized = cleaned.startsWith("sprout-")
    ? cleaned
    : /^\d{9}$/.test(cleaned)
      ? `sprout-${cleaned}`
      : cleaned;
  return `#^${normalized}`;
}

function formatBreadcrumbs(s: string): string {
  return String(s ?? "")
    .replace(/\s*\/\s*/g, " / ")
    .replace(/\s+/g, " ")
    .trim();
}

function formatNotePathForHeader(raw: string): string {
  let s = String(raw ?? "").trim();
  if (!s) return "Note";
  s = s.replace(/\\/g, "/").replace(/^\.\//, "");
  s = s.replace(/\.md$/i, "");
  return formatBreadcrumbs(s);
}

function extractInfoField(card: CardRecord): string | null {
  if (!card) return null;

  const pick = (v: unknown): string | null => {
    if (typeof v === "string" && v.trim()) return v.trim();
    if (Array.isArray(v)) {
      const s = v.filter((x) => typeof x === "string").join("\n").trim();
      return s ? s : null;
    }
    return null;
  };

  return pick(card.info);
}

// --- Basecoat scoping --------------------------------------------------------

/**
 * IMPORTANT:
 * - Add `bc` to every element you want Basecoat to style.
 * - Your PostCSS scoper produces selectors like `.btn-outline.bc`, `div.card.bc`, etc.
 *   so the presence of class `bc` is required for those rules to match.
 */
function h(tag: string, className?: string, text?: string) {
  const node = document.createElement(tag);
  node.className = className && className.trim() ? `bc ${className}` : "bc";
  if (typeof text === "string") node.textContent = text;
  return node;
}

function makeKbd(label: string) {
  const k = document.createElement("kbd");
  k.className = "bc kbd ml-2";
  k.textContent = label;
  return k;
}

function appendKbdRight(btn: HTMLElement, label: string) {
  btn.appendChild(makeKbd(label));
}

function makeTextButton(opts: {
  label: string;
  title?: string;
  className: string;
  onClick: () => void;
  kbd?: string;
}) {
  const btn = document.createElement("button");
  btn.type = "button";
  btn.className = opts.className.split(/\s+/).includes("bc") ? opts.className : `bc ${opts.className}`;
  btn.textContent = opts.label;
  if (opts.title) btn.title = opts.title;

  btn.addEventListener("click", (e) => {
    e.preventDefault();
    e.stopPropagation();
    opts.onClick();
  });

  if (opts.kbd) appendKbdRight(btn, opts.kbd);
  return btn;
}

// --- IO helpers --------------------------------------------------------------

function ioChildKeyFromId(id: string): string | null {
  const m = String(id ?? "").match(/::io::(.+)$/);
  if (!m) return null;
  const k = String(m[1] ?? "").trim();
  return k ? k : null;
}

function getGroupKey(card: CardRecord): string | null {
  if (!card) return null;
  const direct = typeof card.groupKey === "string" && card.groupKey.trim()
    ? card.groupKey.trim()
    : null;
  if (direct) return direct;

  const id = String(card.id ?? "");
  return ioChildKeyFromId(id);
}

function isIoCard(card: CardRecord): boolean {
  const t = String(card?.type ?? "").toLowerCase();
  return t === "io" || t === "io-child";
}

// --- MCQ option order --------------------------------------------------------

function ensureMcqOrderMap(session: Session): Record<string, number[]> {
  if (!session.mcqOrderMap || typeof session.mcqOrderMap !== "object") session.mcqOrderMap = {};
  return session.mcqOrderMap;
}

function isPermutation(arr: unknown, n: number): boolean {
  if (!Array.isArray(arr) || arr.length !== n) return false;
  const seen = new Array<boolean>(n).fill(false);
  for (const raw of arr) {
    const x = Number(raw);
    if (!Number.isInteger(x) || x < 0 || x >= n) return false;
    if (seen[x]) return false;
    seen[x] = true;
  }
  return true;
}

function shuffleInPlace(a: number[]) {
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    const tmp = a[i];
    a[i] = a[j];
    a[j] = tmp;
  }
}

function getMcqDisplayOrder(session: Session, card: CardRecord, enabled: boolean): number[] {
  const opts = card?.options || [];
  const n = Array.isArray(opts) ? opts.length : 0;
  const identity = Array.from({ length: n }, (_, i) => i);

  if (!enabled) return identity;
  if (!session) return identity;

  const id = String(card?.id ?? "");
  if (!id) return identity;

  const map = ensureMcqOrderMap(session);
  const existing = map[id];
  if (isPermutation(existing, n)) return existing;

  const next = identity.slice();
  shuffleInPlace(next);

  // Avoid identity permutation
  if (n >= 2) {
    let same = true;
    for (let i = 0; i < n; i++) {
      if (next[i] !== i) {
        same = false;
        break;
      }
    }
    if (same) {
      const tmp = next[0];
      next[0] = next[1];
      next[1] = tmp;
    }
  }

  map[id] = next;
  return next;
}

// --- Dropdown menu (optional header actions) ---------------------------------

function makeHeaderMenu(opts: {
  canUndo: boolean;
  onUndo: () => void;
  canSkip: boolean;
  onSkip: () => void;
  canBurySuspend: boolean;
  onBury: () => void;
  onSuspend: () => void;
  onExit: () => void;
}) {
  const id = `bc-menu-${Math.random().toString(36).slice(2, 8)}`;

  const root = document.createElement("div");
  root.id = id;
  root.className = "bc relative inline-flex";

  const trigger = document.createElement("button");
  trigger.type = "button";
  trigger.id = `${id}-trigger`;
  trigger.className = "bc btn-outline";
  trigger.dataset.bcAction = "reviewer-more-trigger";
  trigger.setAttribute("aria-haspopup", "menu");
  trigger.setAttribute("aria-controls", `${id}-menu`);
  trigger.setAttribute("aria-expanded", "false");
  trigger.setAttribute("data-tooltip", "More actions");
  trigger.appendChild(document.createTextNode("More"));
  trigger.appendChild(makeKbd("M"));
  root.appendChild(trigger);

  const popover = document.createElement("div");
  popover.id = `${id}-popover`;
  popover.className = "bc sprout";
  popover.setAttribute("aria-hidden", "true");
  popover.classList.add("sprout-popover-overlay");

  const panel = document.createElement("div");
  panel.className = "bc sprout rounded-lg border border-border bg-popover text-popover-foreground shadow-lg p-1 pointer-events-auto";
  popover.appendChild(panel);

  const menu = document.createElement("div");
  menu.className = "bc sprout flex flex-col";
  menu.setAttribute("role", "menu");
  menu.id = `${id}-menu`;
  
  panel.appendChild(menu);

  const addItem = (label: string, hotkey: string | null, onClick: () => void, disabled = false) => {
    const item = document.createElement("div");
    item.className =
      "bc group flex items-center justify-between gap-2 rounded-md px-2 py-1.5 text-sm cursor-pointer select-none outline-none hover:bg-accent hover:text-accent-foreground focus:bg-accent focus:text-accent-foreground";
    item.setAttribute("role", "menuitem");
    item.tabIndex = disabled ? -1 : 0;
    if (disabled) {
      item.classList.add("sprout-menu-item--disabled");
      item.setAttribute("aria-disabled", "true");
    }

    const labelSpan = document.createElement("span");
    labelSpan.className = "bc";
    labelSpan.textContent = label;
    item.appendChild(labelSpan);

    if (hotkey) {
      const key = document.createElement("kbd");
      key.className = "bc kbd ml-auto text-xs text-muted-foreground tracking-widest";
      key.textContent = hotkey;
      item.appendChild(key);
    }

    const activate = () => {
      if (disabled) return;
      onClick();
      close();
    };

    item.addEventListener("click", (e) => {
      e.preventDefault();
      e.stopPropagation();
      activate();
    });

    item.addEventListener("keydown", (e: KeyboardEvent) => {
      if (e.key === "Enter" || e.key === " ") {
        e.preventDefault();
        e.stopPropagation();
        activate();
      }
      if (e.key === "Escape") {
        e.preventDefault();
        e.stopPropagation();
        close();
        trigger.focus();
      }
    });

    menu.appendChild(item);
  };

  // Open Note button
  if (window.sproutOpenCurrentCardNote) {
    addItem("Open", "O", window.sproutOpenCurrentCardNote, false);
  }
  addItem("Bury", "B", opts.onBury, !opts.canBurySuspend);
  addItem("Suspend", "S", opts.onSuspend, !opts.canBurySuspend);
  addItem("Undo last grade", "U", opts.onUndo, !opts.canUndo);
  addItem("Exit to Decks", "Q", opts.onExit);
  if (opts.canSkip) addItem("Skip card", "K", opts.onSkip);

  let cleanup: (() => void) | null = null;

  const place = () => {
    const r = trigger.getBoundingClientRect();
    const margin = 8;
    const width = Math.max(200, Math.round(panel.getBoundingClientRect().width || 0));

    let left = r.right - width;
    if (left + width > window.innerWidth - margin) {
      left = Math.max(margin, window.innerWidth - width - margin);
    }
    if (left < margin) left = margin;

    const panelRect = panel.getBoundingClientRect();
    let top = r.bottom + 6;
    if (top + panelRect.height > window.innerHeight - margin) {
      top = Math.max(margin, r.top - panelRect.height - 6);
    }

    setCssProps(popover, "--sprout-popover-left", `${left}px`);
    setCssProps(popover, "--sprout-popover-top", `${top}px`);
    setCssProps(popover, "--sprout-popover-width", `${width}px`);
  };

  const close = () => {
    trigger.setAttribute("aria-expanded", "false");
    popover.setAttribute("aria-hidden", "true");
    popover.classList.remove("is-open");

    try {
      cleanup?.();
    } catch (e) { log.swallow("render-session close cleanup", e); }
    cleanup = null;

    try {
      popover.remove();
    } catch (e) { log.swallow("render-session close popover.remove", e); }
  };

  const open = () => {
    trigger.setAttribute("aria-expanded", "true");
    popover.setAttribute("aria-hidden", "false");
    popover.classList.add("is-open");

    document.body.appendChild(popover);
    requestAnimationFrame(() => place());

    const onResizeOrScroll = () => place();
    const onDocPointerDown = (ev: PointerEvent) => {
      const t = ev.target as Node | null;
      if (!t) return;
      if (root.contains(t) || popover.contains(t)) return;
      close();
    };
    const onDocKeydown = (ev: KeyboardEvent) => {
      if (ev.key !== "Escape") return;
      ev.preventDefault();
      ev.stopPropagation();
      close();
      trigger.focus();
    };

    window.addEventListener("resize", onResizeOrScroll, true);
    window.addEventListener("scroll", onResizeOrScroll, true);

    const tid = window.setTimeout(() => {
      document.addEventListener("pointerdown", onDocPointerDown, true);
      document.addEventListener("keydown", onDocKeydown, true);
    }, 0);

    cleanup = () => {
      window.clearTimeout(tid);
      window.removeEventListener("resize", onResizeOrScroll, true);
      window.removeEventListener("scroll", onResizeOrScroll, true);
      document.removeEventListener("pointerdown", onDocPointerDown, true);
      document.removeEventListener("keydown", onDocKeydown, true);
    };
  };

  trigger.addEventListener("pointerdown", (ev: PointerEvent) => {
    if (ev.button !== 0) return;
    ev.preventDefault();
    ev.stopPropagation();

    const isOpen = trigger.getAttribute("aria-expanded") === "true";
    if (isOpen) close();
    else open();
  });

  return root;
}

// --- Main -------------------------------------------------------------------

export function renderSessionMode(args: Args) {
  const skipEnabled = !!(args.enableSkipButton ?? args.skipEnabled);
  const practiceMode = !!args.practiceMode;
  const four = !!args.fourButtonMode;
  const applyAOS = !!args.applyAOS;
  const delayMs = Number.isFinite(args.aosDelayMs) ? Number(args.aosDelayMs) : applyAOS ? 100 : 0;

  const canUndo = !!args.canUndo && typeof args.undoLast === "function";
  const hasStartPractice = typeof args.startPractice === "function";
  const canStartPractice = !practiceMode && (!!args.canStartPractice || hasStartPractice);

  const card = args.currentCard();
  const id = card ? String(card.id) : "";
  const graded = args.session?.graded?.[id] || null;

  // ===== Render Study Session header (persists across all card renders) =====
  renderStudySessionHeader(args.container, applyAOS);

  // ===== Root card (Basecoat) =====
  const wrap = document.createElement("div");
  wrap.className = "bc card w-full";
  // Optional: keep a plugin hook class for any small overrides you still want.
  wrap.classList.add("bc-session-card", "sprout-session-card", "m-0");
  const resetAosState = () => {
    wrap.classList.remove("aos-init", "aos-animate", "sprout-aos-fallback");
  };

  // Always render the card, but only apply AOS for front side (not revealed)
  if (applyAOS && !args.showAnswer && !graded) {
    resetAosState();
    wrap.setAttribute("data-aos", "fade-up");
    wrap.setAttribute("data-aos-delay", String(Math.max(0, Math.floor(delayMs))));
  } else {
    // Remove AOS attributes if present and reset state
    wrap.removeAttribute("data-aos");
    wrap.removeAttribute("data-aos-delay");
    resetAosState();
  }

  // Fallback: force visible if AOS fails or never initializes
  setTimeout(() => {
    if (!wrap) return;
    const style = getComputedStyle(wrap);
    if (style.opacity === "0") {
      wrap.classList.add("sprout-aos-fallback");
    }
  }, 350);

  // Reset deck browser aos-once attribute if present
  if (args.container?.dataset?.deckBrowserAosOnce === "1") {
    args.container.dataset.deckBrowserAosOnce = "0";
  }

  // ===== Quit button: Lucide X icon in top right =====
  const quitBtn = document.createElement("button");
  quitBtn.type = "button";
  quitBtn.className = "bc btn-icon sprout-quit-btn";
  quitBtn.setAttribute("data-tooltip", "Quit study session");
  const quitSvg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  quitSvg.setAttribute("xmlns", "http://www.w3.org/2000/svg");
  quitSvg.setAttribute("width", "20");
  quitSvg.setAttribute("height", "20");
  quitSvg.setAttribute("viewBox", "0 0 24 24");
  quitSvg.setAttribute("fill", "none");
  quitSvg.setAttribute("stroke", "currentColor");
  quitSvg.setAttribute("stroke-width", "2");
  quitSvg.setAttribute("stroke-linecap", "round");
  quitSvg.setAttribute("stroke-linejoin", "round");
  quitSvg.classList.add("lucide", "lucide-x");

  const line1 = document.createElementNS("http://www.w3.org/2000/svg", "line");
  line1.setAttribute("x1", "18");
  line1.setAttribute("y1", "6");
  line1.setAttribute("x2", "6");
  line1.setAttribute("y2", "18");
  quitSvg.appendChild(line1);

  const line2 = document.createElementNS("http://www.w3.org/2000/svg", "line");
  line2.setAttribute("x1", "6");
  line2.setAttribute("y1", "6");
  line2.setAttribute("x2", "18");
  line2.setAttribute("y2", "18");
  quitSvg.appendChild(line2);

  quitBtn.appendChild(quitSvg);
  quitBtn.addEventListener("click", () => args.backToDecks());

  // Create section once for both empty and card-present states
  const section = document.createElement("section");
  section.className = "bc flex flex-col gap-3";

  // ===== Empty state rendered like a normal card =====
  if (!card) {
    args.clearTimer();
    args.clearCountdown();

    // Header
    const header = document.createElement("header");
    header.className = "bc flex flex-col gap-4 pt-4 p-6";
    wrap.appendChild(header);

    const locationRaw = args.session?.scope?.name || "Home";
    const location = formatNotePathForHeader(locationRaw);

    const locationRow = document.createElement("div");
    locationRow.className = "bc flex items-center gap-2 min-w-0 px-4";
    header.appendChild(locationRow);

    const locationEl = document.createElement("div");
    locationEl.className = "bc text-muted-foreground pt-4 text-xs text-center italic";
    locationEl.textContent = location || "Home";
    locationRow.appendChild(locationEl);
    locationRow.appendChild(quitBtn);

    const titleSetting = new Setting(header)
      .setName(practiceMode ? "Practice complete" : "No cards are due")
      .setHeading();
    titleSetting.settingEl.classList.add("bc");
    titleSetting.nameEl.classList.add(
      "text-lg",
      "font-bold",
      "leading-none",
      "whitespace-pre-wrap",
      "break-words",
      "text-center",
      "bc-question-title",
    );

    // Section: Practice session message (centered, no alert wrapper)
    if (practiceMode) {
      const d1 = document.createElement("div");
      d1.className = "bc text-base text-center";
      d1.textContent = "Practice session complete";
      const d2 = document.createElement("div");
      d2.className = "bc text-sm text-center";
      d2.textContent =
        "This was a practice session. Scheduling was not changed. You cannot bury or suspend cards in this mode.";
      section.appendChild(d1);
      section.appendChild(d2);
    } else {
      const d1 = document.createElement("div");
      d1.className = "bc text-base text-center";
      d1.textContent = "Would you like to start a practice session?";
      const d2 = document.createElement("div");
      d2.className = "bc text-sm text-center";
      d2.textContent =
        "Practice session reviews all cards in this deck, including ones that are not due. It does not affect scheduling. You cannot bury or suspend cards while in this mode";
      section.appendChild(d1);
      section.appendChild(d2);
    }
    wrap.appendChild(section);

    // Footer: single primary action; no Undo or More
    const footer = document.createElement("footer");
    footer.className = "bc flex flex-row items-center justify-center gap-3 p-10";
    wrap.appendChild(footer);
    const footerCenter = document.createElement("div");
    footerCenter.className = "bc flex flex-wrap gap-2 items-center";
    footer.appendChild(footerCenter);

    if (practiceMode) {
      const backBtn = makeTextButton({
        label: "Return to Decks",
        className: "btn-outline",
        onClick: () => args.backToDecks(),
        kbd: "Q",
      });
      footerCenter.appendChild(backBtn);
    } else if (canStartPractice && hasStartPractice) {
      const backBtn = makeTextButton({
        label: "Return to Decks",
        className: "btn-outline",
        onClick: () => args.backToDecks(),
        kbd: "Q",
      });
      footerCenter.appendChild(backBtn);

      const startBtn = makeTextButton({
        label: "Start Practice",
        className: "btn",
        onClick: () => args.startPractice?.(),
        kbd: "↵",
      });
      startBtn.classList.add("sprout-btn-start-practice");
      footerCenter.appendChild(startBtn);
    }

    args.container.appendChild(wrap);
    requestAnimationFrame(() => {
      requestAnimationFrame(() => {
        try {
          refreshAOS();
        } catch (e) { log.swallow("render-session refreshAOS empty", e); }
      });
    });
    return;
  }

  // Card present
  args.clearCountdown();

  // ===== Header =====
  const header = document.createElement("header");
  header.className = "bc flex flex-col gap-4 pt-4 p-6";
  wrap.appendChild(header);

  const locationRaw = card.sourceNotePath || args.session?.scope?.name || "Note";
  const location = formatNotePathForHeader(locationRaw);

  // Location row
  const locationRow = document.createElement("div");
  locationRow.className = "bc flex items-center gap-2 min-w-0 px-4";
  header.appendChild(locationRow);

  const locationEl = document.createElement("div");
  locationEl.className = "bc text-muted-foreground pt-4 text-xs text-center italic";
  locationEl.textContent = location || "Note";
  locationRow.appendChild(locationEl);
  locationRow.appendChild(quitBtn);

  // Title below location
  const ioLike = isIoCard(card);
  let displayTitle = card.title || "";

  // Remove cloze number suffix (e.g., " • c1", " • c2", etc.) from cloze cards
  if (card.type === "cloze" || card.type === "cloze-child") {
    displayTitle = displayTitle.replace(/\s*•\s*c\d+\s*$/, "");
  }

  const titleText =
    displayTitle ||
    (card.type === "mcq"
      ? "MCQ"
      : card.type === "cloze" || card.type === "cloze-child"
        ? "Cloze"
        : ioLike
          ? (() => {
              const k = getGroupKey(card);
              return k ? `Image Occlusion • ${k}` : "Image Occlusion";
            })()
          : "Basic");

  const sourcePath = String(card.sourceNotePath || args.session?.scope?.name || "");

  const titleSetting = new Setting(header).setName("").setHeading();
  titleSetting.settingEl.classList.add("bc");
  titleSetting.nameEl.classList.add(
    "text-lg",
    "font-bold",
    "leading-none",
    "whitespace-pre-wrap",
    "break-words",
    "text-center",
    "bc-question-title",
  );
  const titleEl = titleSetting.nameEl;
  // Render title as markdown to support wiki links and LaTeX
  const titleMd = String(titleText ?? "");
  if (titleMd.includes('[[') || titleMd.includes('$')) {
    void args.renderMarkdownInto(titleEl, titleMd, sourcePath).then(() => setupLinkHandlers(titleEl, sourcePath));
  } else {
    applyInlineMarkdown(titleEl, titleMd);
  }

  // ===== Content =====
  const mutedLabel = (s: string) => h("div", "text-muted-foreground text-sm font-medium", s);

  const setupLinkHandlers = (rootEl: HTMLElement, srcPath: string) => {
    const app = window?.app;
    const links = rootEl.querySelectorAll<HTMLAnchorElement>("a");
    links.forEach((link) => {
      link.addEventListener("click", (e) => {
        const href = link.getAttribute("data-href") || link.getAttribute("href") || "";
        if (!href) return;
        e.preventDefault();
        e.stopPropagation();

        const isExternal = /^(https?:|mailto:|tel:)/i.test(href);
        if (isExternal) {
          window.open(href, "_blank", "noopener");
          return;
        }

        if (app?.workspace?.openLinkText) {
          void app.workspace.openLinkText(href, srcPath || "", true);
        } else {
          window.open(href, "_blank", "noopener");
        }
      });

      link.setAttribute("target", "_blank");
      link.setAttribute("rel", "noopener");
    });
  };

  const renderMdBlock = (cls: string, md: string) => {
    const block = document.createElement("div");
    block.className = `bc ${cls} whitespace-pre-wrap break-words sprout-md-block`;
    void args.renderMarkdownInto(block, md ?? "", sourcePath).then(() => setupLinkHandlers(block, sourcePath));
    return block;
  };

  if (card.type === "basic") {
    section.appendChild(mutedLabel("Question"));
    section.appendChild(renderMdBlock("bc-q", card.q || ""));

    if (args.showAnswer || graded) {
      section.appendChild(mutedLabel("Answer"));
      section.appendChild(renderMdBlock("bc-a", card.a || ""));
    }
  } else if (card.type === "cloze" || card.type === "cloze-child") {
    const text = String(card.clozeText || "");
    const reveal = args.showAnswer || !!graded;
    const targetIndex = card.type === "cloze-child" ? Number(card.clozeIndex) : null;

    section.appendChild(mutedLabel(reveal ? "Answer" : "Question"));
    const clozContainer = document.createElement("div");
    clozContainer.className = "bc bc-cloze whitespace-pre-wrap break-words sprout-md-block";
    const clozeContent = args.renderClozeFront(text, reveal, targetIndex);
    if (reveal) {
      const span = document.createElement("span");
      span.className = "bc whitespace-pre-wrap break-words";
      span.appendChild(clozeContent);
      clozContainer.appendChild(span);
    } else {
      clozContainer.appendChild(clozeContent);
    }
    section.appendChild(clozContainer);
  } else if (card.type === "mcq") {
    section.appendChild(mutedLabel("Question"));
    section.appendChild(renderMdBlock("bc-q", card.stem || ""));
    const reveal = !!graded || !!args.showAnswer;
    section.appendChild(mutedLabel(reveal ? "Answer" : "Options"));

    // Only show MCQ options, not info, as answer options
    const opts = (card.options || [] as Array<{ text: string; isCorrect: boolean } | string>).filter((opt) => {
      if (typeof opt === "string") return true;
      return !opt.isCorrect || (opt.isCorrect && (card.a || "").trim() === opt.text.trim());
    });
    const chosenOrigIdx = (graded?.meta as Record<string, unknown> | undefined)?.mcqChoice;
    const order = getMcqDisplayOrder(args.session, card, !!args.randomizeMcqOptions);

    const optionList = document.createElement("div");
    optionList.className = "bc flex flex-col gap-2 sprout-mcq-options";
    section.appendChild(optionList);

    order.forEach((origIdx: number, displayIdx: number) => {
      const opt = opts[origIdx] ?? {};
      const text = typeof opt === "string" ? opt : (opt && typeof (opt as Record<string, unknown>).text === "string" ? (opt as Record<string, unknown>).text as string : "");

      const btn = document.createElement("button");
      btn.type = "button";
      btn.className = "bc btn-outline w-full justify-start text-left h-auto py-2 mb-2";

      // Apply correctness styles on back of card (revealed).
      // Show green border on the correct option, red border on all non-correct options.
      // If graded, the chosen wrong option is also explicitly marked.
      if (reveal) {
        const isCorrect = origIdx === card.correctIndex;
        const isChosen = !!graded && typeof chosenOrigIdx === "number" && chosenOrigIdx === origIdx;
        const isChosenWrong = isChosen && chosenOrigIdx !== card.correctIndex;

        if (isCorrect) {
          btn.classList.add("bc-mcq-correct", "sprout-mcq-correct-highlight");
        }

        if (isChosenWrong) {
          btn.classList.add("bc-mcq-wrong", "sprout-mcq-wrong-highlight");
        }
      }

      const left = document.createElement("span");
      left.className = "bc inline-flex items-center gap-2 min-w-0";

      const key = document.createElement("kbd");
      key.className = "bc kbd";
      key.textContent = String(displayIdx + 1);
      left.appendChild(key);

      // Render option text with markdown support for wiki links and LaTeX
      const textEl = document.createElement("span");
      textEl.className = "bc min-w-0 whitespace-pre-wrap break-words sprout-mcq-option-text";
      
      // Use markdown rendering if text contains wiki links or LaTeX
      if (text && (text.includes('[[') || text.includes('$'))) {
        void args.renderMarkdownInto(textEl, text, sourcePath).then(() => setupLinkHandlers(textEl, sourcePath));
      } else if (text && text.includes("\n")) {
        text.split(/\n+/).forEach((line: string) => {
          const p = document.createElement("div");
          applyInlineMarkdown(p, line);
          p.classList.add("sprout-mcq-option-line");
          textEl.appendChild(p);
        });
      } else {
        applyInlineMarkdown(textEl, text);
      }
      left.appendChild(textEl);

      btn.appendChild(left);

      btn.addEventListener("click", (e) => {
        e.preventDefault();
        e.stopPropagation();
        if (!graded) void args.answerMcq(origIdx);
      });

      optionList.appendChild(btn);
    });

    // Do not render separate Answer subtitle/content for MCQ.
  } else if (ioLike) {
    const reveal = !!graded || !!args.showAnswer;

    const ioHost = document.createElement("div");
    ioHost.className = "bc bc-io-host";
    ioHost.dataset.sproutIoWidget = "1";
    section.appendChild(ioHost);

    if (typeof args.renderImageOcclusionInto === "function") {
      void args.renderImageOcclusionInto(ioHost, card, sourcePath, reveal);
    } else {
      const md = String(card.imageRef ?? "");
      if (md.trim()) void args.renderMarkdownInto(ioHost, md, sourcePath).then(() => setupLinkHandlers(ioHost, sourcePath));
      else ioHost.appendChild(h("div", "text-muted-foreground text-sm", "IO card missing image source."));
    }
  }

  const infoText = extractInfoField(card);
  const isBack = !!graded || !!args.showAnswer;
  const shouldShowInfo =
    (card.type === "basic" && isBack && !!infoText) || ((args.showInfo || graded) && !!infoText);
  if (shouldShowInfo) {
    section.appendChild(mutedLabel("Extra information"));
    section.appendChild(renderMdBlock("bc-info", infoText));
  }

  // Append section to wrap
  wrap.appendChild(section);

  // ===== Footer (actions) =====
  const footer = document.createElement("footer");
  footer.className = "bc flex flex-row items-center justify-between gap-4 p-10";
  wrap.appendChild(footer);

  // Left: Edit button
  const footerLeft = document.createElement("div");
  footerLeft.className = "bc flex items-center gap-2";

  const editBtn = makeTextButton({
    label: "Edit",
    className: "btn-outline",
    onClick: () => {
      args.openEditModal?.();
    },
    kbd: "E",
  });
  footerLeft.appendChild(editBtn);
  footer.appendChild(footerLeft);

  // Center: Reveal/Grade/Next buttons
  const footerCenter = document.createElement("div");
  footerCenter.className = "bc flex flex-wrap gap-2 items-center";
  footer.appendChild(footerCenter);

  const canGradeNow =
    !graded &&
    ((card.type === "basic" || card.type === "cloze" || card.type === "cloze-child" || ioLike) && !!args.showAnswer);

  // Basic/Cloze/IO: reveal gate
  if (
    (card.type === "basic" || card.type === "cloze" || card.type === "cloze-child" || ioLike) &&
    !args.showAnswer &&
    !graded
  ) {
    footerCenter.appendChild(
      makeTextButton({
        label: "Reveal",
        className: "btn",
        onClick: () => {
          args.setShowAnswer(true);
          args.rerender();
        },
        kbd: "↵",
      }),
    );
  }

  // Grading / next buttons (in center)
  const mainRow = document.createElement("div");
  mainRow.className = "bc flex flex-wrap items-center gap-2";
  let hasMainRowContent = false;

  if (!graded) {
    if (canGradeNow) {
      const goNext = () => void args.nextCard(true);

      // Practice mode: single Continue button
      if (practiceMode) {
        const continueBtn = makeTextButton({
          label: "Continue",
          className: "btn",
          onClick: goNext,
          kbd: "↵",
        });
        continueBtn.classList.add("sprout-btn-easy");
        mainRow.appendChild(continueBtn);
        hasMainRowContent = true;
      } else {
        // Normal mode: grading buttons
        const group = document.createElement("div");
        group.className = "bc flex flex-wrap gap-2";
        mainRow.appendChild(group);
        hasMainRowContent = true;

        const againBtn = makeTextButton({
          label: "Again",
          className: "btn-destructive",
          onClick: () => void args.gradeCurrentRating("again", {}).then(goNext),
          kbd: "1",
        });
        againBtn.classList.add("sprout-btn-again");
        group.appendChild(againBtn);

        if (four) {
          const hardBtn = makeTextButton({
            label: "Hard",
            className: "btn",
            onClick: () => void args.gradeCurrentRating("hard", {}).then(goNext),
            kbd: "2",
          });
          hardBtn.classList.add("sprout-btn-hard");
          group.appendChild(hardBtn);

          const goodBtn = makeTextButton({
            label: "Good",
            className: "btn",
            onClick: () => void args.gradeCurrentRating("good", {}).then(goNext),
            kbd: "3",
          });
          goodBtn.classList.add("sprout-btn-good");
          group.appendChild(goodBtn);

          const easyBtn = makeTextButton({
            label: "Easy",
            className: "btn",
            onClick: () => void args.gradeCurrentRating("easy", {}).then(goNext),
            kbd: "4",
          });
          easyBtn.classList.add("sprout-btn-easy");
          group.appendChild(easyBtn);
        } else {
          const goodBtn = makeTextButton({
            label: "Good",
            className: "btn",
            onClick: () => void args.gradeCurrentRating("good", {}).then(goNext),
            kbd: "2",
          });
          goodBtn.classList.add("sprout-btn-good");
          group.appendChild(goodBtn);
        }
      }

      if (skipEnabled) {
        const skipBtn = makeTextButton({
          label: "Skip",
          className: "btn-outline",
          onClick: () => args.skipCurrentCard({ uiSource: "skip-btn", uiKey: 13, uiButtons: four ? 4 : 2 }),
          kbd: "↵",
        });
        skipBtn.dataset.bcAction = "skip-card";
        skipBtn.title = "Skip (↵)";
        mainRow.appendChild(skipBtn);
      }
    } else if (card.type === "mcq") {
      const optCount = (card.options || []).length;
      mainRow.appendChild(h("div", "text-muted-foreground text-sm", `Choose 1–${optCount}.`));
      hasMainRowContent = true;
    } else if (ioLike && !args.showAnswer) {
      mainRow.appendChild(h("div", "text-muted-foreground text-sm", "Press Enter to reveal the image."));
      hasMainRowContent = true;
    }
  } else {
    mainRow.appendChild(
      makeTextButton({
        label: "Next",
        className: "btn",
        onClick: () => void args.nextCard(true),
        kbd: "↵",
      }),
    );
    hasMainRowContent = true;
  }

  // Only append mainRow if it has content
  if (hasMainRowContent) {
    footerCenter.appendChild(mainRow);
  }

  // Right: More menu
  const footerRight = document.createElement("div");
  footerRight.className = "bc flex items-center gap-2";

  // Provide open note handler globally for menu
  window.sproutOpenCurrentCardNote = () => {
    if (!card) return;
    const filePath = card.sourceNotePath;
    if (!filePath) return;
    const anchorStr = buildCardAnchorFragment(card.id);
    const app = window.app;
    if (app && app.workspace && typeof app.workspace.openLinkText === 'function') {
      void app.workspace.openLinkText(filePath + anchorStr, filePath, true);
    }
  };
  footerRight.appendChild(
    makeHeaderMenu({
      canUndo,
      onUndo: () => args.undoLast?.(),
      canBurySuspend: !!args.canBurySuspend,
      onBury: () => args.buryCurrentCard?.(),
      onSuspend: () => args.suspendCurrentCard?.(),
      canSkip: skipEnabled && !!card && !graded,
      onSkip: () => args.skipCurrentCard({ uiSource: "footer-menu" }),
      onExit: () => args.backToDecks(),
    }),
  );
  footer.appendChild(footerRight);

  args.container.appendChild(wrap);
  // Always refresh AOS to ensure animations work across the page
  requestAnimationFrame(() => {
    requestAnimationFrame(() => {
      try {
        refreshAOS();
      } catch (e) { log.swallow("render-session refreshAOS card", e); }
    });
  });
}
