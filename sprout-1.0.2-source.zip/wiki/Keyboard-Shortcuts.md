## Overview

## Cloze creation (Cloze modal)

- New cloze (next number): Cmd+Shift+C (Mac) / Ctrl+Shift+C (Windows/Linux)
- Same cloze number: Cmd+Shift+Option+C (Mac) / Ctrl+Shift+Alt+C (Windows/Linux)

## Markdown source view

- Insert cloze (always c1): Cmd+Shift+C (Mac) / Ctrl+Shift+C (Windows/Linux)

## Study session

- Enter: Reveal answer / advance when graded
- 1–2 (two-button mode): Again / Good
- 1–4 (four-button mode): Again / Hard / Good / Easy
- E: Edit current card
- O: Open card in note
- M: More menu
- Q or Esc: Exit session / back to decks
- B: Bury card (when available)
- S: Suspend card (when available)
- U: Undo last grade
- ArrowLeft: Previous card / hide answer
- MCQ: 1–9 selects option
