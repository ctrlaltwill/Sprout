module.exports = {
  corePlugins: {
    preflight: false,
  }
}