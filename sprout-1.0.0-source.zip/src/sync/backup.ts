/**
 * @file src/sync/backup.ts
 * @summary Backup management for the Sprout data store (data.json). Provides CRUD operations for listing, creating, restoring, and deleting backup snapshots, routine backup scheduling invoked by the sync engine, and low-level adapter/filesystem utilities shared with the sync engine.
 *
 * @exports
 *  - isPlainObject                 — type guard that checks if a value is a plain object
 *  - countObjectKeys               — returns the number of own enumerable keys on an object
 *  - joinPath                      — joins path segments with forward slashes
 *  - likelySproutStateKey          — heuristic check for whether a key looks like a Sprout card state key
 *  - extractStatesFromDataJsonObject — extracts card-state entries from a parsed data.json object
 *  - tryReadJson                   — safely reads and parses a JSON file from the vault adapter
 *  - safeListFolders               — lists subfolders with error handling for missing paths
 *  - safeListFiles                 — lists files in a folder with error handling
 *  - safeStatMtime                 — returns a file's mtime or null on error
 *  - getPluginId                   — returns the plugin's ID from the manifest
 *  - DataJsonBackupEntry           — type describing a single backup file entry (path, timestamp, size)
 *  - DataJsonBackupStats           — type describing aggregate backup statistics
 *  - listDataJsonBackups           — lists all available data.json backup files
 *  - getDataJsonBackupStats        — computes summary statistics for existing backups
 *  - createDataJsonBackupNow       — creates a new backup of the current data.json immediately
 *  - restoreFromDataJsonBackup     — restores the data store from a chosen backup file
 *  - ensureRoutineBackupIfNeeded   — creates a routine backup if enough time has elapsed since the last one
 */

import type SproutPlugin from "../main";
import type { DataAdapter } from "obsidian";
import { MS_DAY } from "../core/constants";

/**
 * Minimal adapter-like interface for low-level vault filesystem access.
 * Matches the subset of Obsidian's DataAdapter that backup/sync helpers
 * actually touch, allowing feature-detection for optional methods.
 */
type AdapterLike = Partial<Pick<DataAdapter, "read" | "write" | "exists" | "remove" | "rename" | "list" | "stat">>;

// ────────────────────────────────────────────
// Module-level constants & mutable state
// ────────────────────────────────────────────

/** Maximum number of automatic backup files to keep on disk. */
const BACKUP_MAX_COUNT = 12;

/** Minimum interval between automatic (routine) backups. */
const ROUTINE_BACKUP_MIN_INTERVAL_MS = MS_DAY;

/** Cooldown to avoid re-checking backup necessity on every sync. */
const ROUTINE_CHECK_COOLDOWN_MS = 5 * 60 * 1000;

/** Tracks the last time we checked whether a routine backup was needed. */
let lastRoutineBackupCheck = 0;

// ────────────────────────────────────────────
// Generic low-level utilities
// (exported so sync-engine.ts can re-use them)
// ────────────────────────────────────────────

/** Returns `true` if `v` is a non-null, non-array plain object. */
export function isPlainObject(v: unknown): v is Record<string, unknown> {
  return !!v && typeof v === "object" && !Array.isArray(v);
}

/** Safely counts the number of own keys on a plain object. */
export function countObjectKeys(v: unknown): number {
  return isPlainObject(v) ? Object.keys(v).length : 0;
}

/** Joins path segments with `/`, collapsing duplicate slashes. */
export function joinPath(...parts: string[]): string {
  return parts
    .filter((p) => typeof p === "string" && p.length)
    .join("/")
    .replace(/\/+/g, "/");
}

/**
 * Heuristic: returns `true` if `k` looks like a Sprout-generated
 * card-state key (9-digit parent or `parent::cloze::cN` child).
 */
export function likelySproutStateKey(k: string): boolean {
  return /^\d{9}$/.test(k) || /^\d{9}::cloze::c\d+$/.test(k) || /^\d{9}::/.test(k);
}

/**
 * Tries to extract a `states` object from a parsed data.json structure.
 * Supports both `{ states: {...} }` and `{ data: { states: {...} } }`.
 */
export function extractStatesFromDataJsonObject(obj: unknown): Record<string, unknown> | null {
  if (!obj) return null;
  const o = obj as Record<string, unknown>;
  const root = isPlainObject(o.data) ? o.data : o;
  const states = (root)?.states;
  if (!isPlainObject(states)) return null;
  return states;
}

// ────────────────────────────────────────────
// Vault adapter helpers
// ────────────────────────────────────────────

/**
 * Attempts to read and parse a JSON file from the vault adapter.
 * Returns `null` on any failure (missing file, bad JSON, etc.).
 */
export async function tryReadJson(adapter: AdapterLike | null, path: string): Promise<unknown> {
  try {
    if (!adapter) return null;
    if (adapter.exists) {
      const exists = await adapter.exists(path);
      if (!exists) return null;
    }
    if (!adapter.read) return null;
    const text = await adapter.read(path);
    if (!text || !String(text).trim()) return null;
    try {
      return JSON.parse(String(text));
    } catch {
      return null;
    }
  } catch {
    return null;
  }
}

/** Lists sub-folders inside `path` using the vault adapter. */
export async function safeListFolders(adapter: AdapterLike | null, path: string): Promise<string[]> {
  try {
    if (!adapter) return [];
    if (adapter.list) {
      const res = await adapter.list(path);
      const folders = Array.isArray(res?.folders) ? res.folders : [];
      return folders.map((p) => String(p)).filter(Boolean);
    }
    const readdir = (adapter as unknown as Record<string, unknown>).readdir as ((p: string) => Promise<{ folders?: string[] }>) | undefined;
    if (readdir) {
      const res = await readdir(path);
      const folders = Array.isArray(res?.folders) ? res.folders : [];
      return folders.map((p) => String(p)).filter(Boolean);
    }
  } catch {
    // ignore
  }
  return [];
}

/** Lists files inside `path` using the vault adapter. */
export async function safeListFiles(adapter: AdapterLike | null, path: string): Promise<string[]> {
  try {
    if (!adapter) return [];
    if (adapter.list) {
      const res = await adapter.list(path);
      const files = Array.isArray(res?.files) ? res.files : [];
      return files.map((p) => String(p)).filter(Boolean);
    }
    const readdir = (adapter as unknown as Record<string, unknown>).readdir as ((p: string) => Promise<{ files?: string[] }>) | undefined;
    if (readdir) {
      const res = await readdir(path);
      const files = Array.isArray(res?.files) ? res.files : [];
      return files.map((p) => String(p)).filter(Boolean);
    }
  } catch {
    // ignore
  }
  return [];
}

/** Returns the mtime of a file (0 on failure). */
export async function safeStatMtime(adapter: AdapterLike | null, path: string): Promise<number> {
  try {
    if (adapter?.stat) {
      const st = await adapter.stat(path);
      const m = Number(st?.mtime ?? 0);
      return Number.isFinite(m) ? m : 0;
    }
  } catch {
    // ignore
  }
  return 0;
}

/** Returns the size of a file in bytes (0 on failure). */
async function safeStatSize(adapter: AdapterLike | null, path: string): Promise<number> {
  try {
    if (adapter?.stat) {
      const st = await adapter.stat(path);
      const s = Number(st?.size ?? 0);
      return Number.isFinite(s) ? s : 0;
    }
  } catch {
    // ignore
  }
  return 0;
}

/** Deletes a file using the adapter's `remove()` or `trash()`. */
async function safeRemoveFile(adapter: AdapterLike | null, path: string): Promise<boolean> {
  try {
    if (!adapter || !path) return false;
    if (adapter.remove) {
      await adapter.remove(path);
      return true;
    }
    const trash = (adapter as unknown as Record<string, unknown>).trash as ((p: string) => Promise<void>) | undefined;
    if (trash) {
      await trash(path);
      return true;
    }
  } catch {
    // ignore
  }
  return false;
}

// ────────────────────────────────────────────
// Backup file detection & pruning
// ────────────────────────────────────────────

/** Returns `true` if the filename matches the backup naming pattern. */
function isBackupFileName(name: string): boolean {
  return /^data\.json\.bak-/.test(String(name ?? ""));
}

/**
 * Prunes old backup files, keeping at most `maxCount` (sorted by mtime desc).
 */
async function pruneDataJsonBackups(plugin: SproutPlugin, maxCount = BACKUP_MAX_COUNT): Promise<void> {
  const adapter = plugin.app?.vault?.adapter;
  const pluginId = getPluginId(plugin);
  if (!adapter || !pluginId) return;

  const folder = joinPath(plugin.app.vault.configDir, "plugins", pluginId);
  const files = await safeListFiles(adapter, folder);
  const backups = files
    .filter((p) => isBackupFileName(String(p).split("/").pop() || ""))
    .map((p) => String(p));

  if (backups.length <= maxCount) return;

  const entries = [];
  for (const p of backups) {
    const mtime = await safeStatMtime(adapter, p);
    entries.push({ path: p, mtime });
  }

  entries.sort((a, b) => b.mtime - a.mtime);
  const remove = entries.slice(maxCount);
  for (const entry of remove) {
    await safeRemoveFile(adapter, entry.path);
  }
}

// ────────────────────────────────────────────
// Plugin ID helper
// ────────────────────────────────────────────

/** Reads the plugin manifest ID (e.g. "sprout-flashcards"). */
export function getPluginId(plugin: SproutPlugin): string | null {
  const id = String(plugin.manifest?.id ?? "").trim();
  return id ? id : null;
}

// ────────────────────────────────────────────
// Backup stats helpers
// ────────────────────────────────────────────

/**
 * Locates the "store-like root" inside a parsed data.json object.
 * Looks for `{ cards, states, reviewLog, quarantine }` either at
 * top level or nested under `.data`, `.store`, or `.db`.
 */
function getStoreLikeRoot(obj: unknown): Record<string, unknown> | null {
  if (!obj || typeof obj !== "object") return null;
  const o = obj as Record<string, unknown>;
  const candidates = [o?.data, o?.store, o?.db, obj] as unknown[];
  for (const c of candidates) {
    if (!isPlainObject(c)) continue;

    const rec = c;
    const hasCards = isPlainObject(rec.cards);
    const hasStates = isPlainObject(rec.states);
    const hasReviewLog = Array.isArray(rec.reviewLog);
    const hasQuarantine = isPlainObject(rec.quarantine);

    if (hasCards || hasStates || hasReviewLog || hasQuarantine) return c;
  }

  return null;
}

/**
 * Computes scheduling summary stats from a `states` object.
 * Returns counts for states, due, learning, review, and mature cards.
 */
function computeSchedulingStats(states: unknown, now: number) {
  const out = { states: 0, due: 0, learning: 0, review: 0, mature: 0 };
  if (!isPlainObject(states)) return out;
  const values = Object.values(states);
  out.states = values.length;
  for (const st of values) {
    if (!st || typeof st !== "object") continue;
    const entry = st as Record<string, unknown>;
    const stageRaw = entry.stage;
    const stage =
      typeof stageRaw === "string"
        ? stageRaw
        : typeof stageRaw === "number"
          ? String(stageRaw)
          : "";
    if (stage === "learning" || stage === "relearning") out.learning += 1;
    if (stage === "review") out.review += 1;
    const stability = Number(entry.stabilityDays ?? 0);
    if (stage === "review" && Number.isFinite(stability) && stability >= 30) out.mature += 1;
    const due = Number(entry.due ?? 0);
    if (stage !== "suspended" && Number.isFinite(due) && due > 0 && due <= now) out.due += 1;
  }
  return out;
}

/**
 * Deep-clones a plain JSON-serialisable value.
 * Uses `structuredClone` when available, otherwise falls back to
 * JSON round-trip.
 */
function clonePlain<T>(x: T): T {
  if (typeof structuredClone === "function") return structuredClone(x);
  return JSON.parse(JSON.stringify(x)) as T;
}

/**
 * Replaces all keys in `target` with those from `source`.
 * Mutates in-place to preserve existing object references (important
 * for `plugin.store.data`).
 */
function replaceObjectContents(target: Record<string, unknown>, source: Record<string, unknown>) {
  if (!target || typeof target !== "object") return;
  for (const k of Object.keys(target)) delete target[k];
  for (const k of Object.keys(source || {})) target[k] = source[k];
}

// ────────────────────────────────────────────
// Exported types
// ────────────────────────────────────────────

/** A single backup file entry (path + filesystem metadata). */
export type DataJsonBackupEntry = {
  path: string;
  name: string;
  mtime: number;
  size: number;
};

/** Extended backup entry with parsed scheduling/stat data. */
export type DataJsonBackupStats = DataJsonBackupEntry & {
  version: number;
  cards: number;
  states: number;
  due: number;
  learning: number;
  review: number;
  mature: number;
  reviewLog: number;
  quarantine: number;
  io: number;
  sproutishStateKeys: number;
};

// ────────────────────────────────────────────
// Backup CRUD functions
// ────────────────────────────────────────────

/**
 * Lists all data.json backup files in the plugin folder.
 * Sorted newest-first by mtime.
 */
export async function listDataJsonBackups(plugin: SproutPlugin): Promise<DataJsonBackupEntry[]> {
  const adapter = plugin.app?.vault?.adapter;
  const pluginId = getPluginId(plugin);
  if (!adapter || !pluginId) return [];

  const folder = joinPath(plugin.app.vault.configDir, "plugins", pluginId);
  const files = await safeListFiles(adapter, folder);

  // Include data.json and any data.json.* (bak-*, prev, old, etc.)
  const cand = files.filter((p) => /(^|\/)data\.json(\..+)?$/.test(String(p)));

  const out: DataJsonBackupEntry[] = [];
  for (const p of cand) {
    const path = String(p);
    const name = path.split("/").pop() || path;
    const mtime = await safeStatMtime(adapter, path);
    const size = await safeStatSize(adapter, path);
    out.push({ path, name, mtime, size });
  }

  out.sort((a, b) => b.mtime - a.mtime || b.size - a.size || a.name.localeCompare(b.name));
  return out;
}

/**
 * Reads and parses a backup file to extract scheduling/card statistics.
 * Returns `null` if the file can't be read or doesn't contain valid data.
 */
export async function getDataJsonBackupStats(plugin: SproutPlugin, path: string): Promise<DataJsonBackupStats | null> {
  const adapter = plugin.app?.vault?.adapter;
  if (!adapter || !path) return null;

  const obj = await tryReadJson(adapter, path);
  const root = getStoreLikeRoot(obj);
  if (!root) return null;

  const cards = root.cards;
  const states = root.states;
  const reviewLog = root.reviewLog;
  const quarantine = root.quarantine;
  const io = root.io;

  const cardCount = countObjectKeys(cards);
  const stateKeys = isPlainObject(states) ? Object.keys(states) : [];
  const stateCount = stateKeys.length;
  const sproutishStateKeys = stateKeys.reduce((acc, k) => acc + (likelySproutStateKey(k) ? 1 : 0), 0);
  const sched = computeSchedulingStats(states, Date.now());

  const reviewCount = Array.isArray(reviewLog) ? reviewLog.length : 0;
  const quarantineCount = countObjectKeys(quarantine);
  const ioCount = countObjectKeys(io);

  const entry: DataJsonBackupEntry = {
    path,
    name: String(path).split("/").pop() || String(path),
    mtime: await safeStatMtime(adapter, path),
    size: await safeStatSize(adapter, path),
  };

  return {
    ...entry,
    version: Number(root.version ?? 0) || 0,
    cards: cardCount,
    states: stateCount,
    due: sched.due,
    learning: sched.learning,
    review: sched.review,
    mature: sched.mature,
    reviewLog: reviewCount,
    quarantine: quarantineCount,
    io: ioCount,
    sproutishStateKeys,
  };
}

/**
 * Creates a timestamped backup of the current data.json on disk.
 * Returns the backup file path, or `null` on failure.
 */
export async function createDataJsonBackupNow(plugin: SproutPlugin, label?: string): Promise<string | null> {
  const adapter = plugin.app?.vault?.adapter;
  const pluginId = getPluginId(plugin);
  if (!adapter || !pluginId) return null;

  const dataPath = joinPath(plugin.app.vault.configDir, "plugins", pluginId, "data.json");
  if (typeof adapter.exists !== "function" || typeof adapter.read !== "function" || typeof adapter.write !== "function") return null;

  try {
    const exists = await adapter.exists(dataPath);
    if (!exists) return null;

    const text = await adapter.read(dataPath);
    if (!text || !String(text).trim()) return null;
    if (String(text).trim() === "{}") return null;

    const ts = new Date().toISOString().replace(/[:.]/g, "-");
    const cleanLabel = String(label ?? "")
      .trim()
      .toLowerCase()
      .replace(/[^a-z0-9_-]+/g, "-")
      .replace(/-+/g, "-")
      .replace(/^-|-$/g, "");

    const suffix = cleanLabel ? `-${cleanLabel}` : "";
    const backupPath = joinPath(plugin.app.vault.configDir, "plugins", pluginId, `data.json.bak-${ts}${suffix}`);
    await adapter.write(backupPath, String(text));
    await pruneDataJsonBackups(plugin, BACKUP_MAX_COUNT);
    return backupPath;
  } catch {
    return null;
  }
}

/**
 * Restores the Sprout database from a backup file on disk.
 * Optionally creates a safety backup before overwriting.
 *
 * Mutates `plugin.store.data` in-place and persists.
 */
export async function restoreFromDataJsonBackup(
  plugin: SproutPlugin,
  backupPath: string,
  opts: { makeSafetyBackup?: boolean } = {},
): Promise<{ ok: boolean; message: string }> {
  const adapter = plugin.app?.vault?.adapter;
  if (!adapter) return { ok: false, message: "No vault adapter available." };
  if (!backupPath) return { ok: false, message: "No backup path provided." };

  try {
    if (opts.makeSafetyBackup) {
      await createDataJsonBackupNow(plugin, "before-restore");
    }

    const obj = await tryReadJson(adapter, backupPath);
    const root = getStoreLikeRoot(obj);
    if (!root) return { ok: false, message: "Backup JSON did not contain a recognisable store/database structure." };

    // Only restore the store-like root (cards/states/reviewLog/quarantine/io/version/etc.)
    const snapshot = clonePlain(root);

    // Ensure required keys exist (avoid undefined holes)
    snapshot.cards ??= {};
    snapshot.states ??= {};
    snapshot.reviewLog ??= [];
    snapshot.quarantine ??= {};
    snapshot.io ??= snapshot.io ?? {};
    snapshot.version = Math.max(Number(snapshot.version ?? 0) || 0, 1);

    // Mutate-in-place to preserve references to plugin.store.data
    replaceObjectContents(plugin.store.data as unknown as Record<string, unknown>, snapshot);

    // Persist through the store
    await plugin.store.persist();

    return { ok: true, message: "Restore completed." };
  } catch (e: unknown) {
    const errMsg =
      e instanceof Error
        ? e.message
        : typeof e === "string"
          ? e
          : "unknown error";
    return { ok: false, message: `Restore failed: ${errMsg}` };
  }
}

// ────────────────────────────────────────────
// Routine backup (called by sync engine)
// ────────────────────────────────────────────

/**
 * Checks whether enough time has elapsed since the last automatic backup
 * and creates one if needed.  Throttled by `ROUTINE_CHECK_COOLDOWN_MS`
 * and `ROUTINE_BACKUP_MIN_INTERVAL_MS`.
 */
export async function ensureRoutineBackupIfNeeded(plugin: SproutPlugin): Promise<void> {
  const now = Date.now();
  if (now - lastRoutineBackupCheck < ROUTINE_CHECK_COOLDOWN_MS) return;
  lastRoutineBackupCheck = now;

  const adapter = plugin.app?.vault?.adapter;
  const pluginId = getPluginId(plugin);
  if (!adapter || !pluginId) return;

  const folder = joinPath(plugin.app.vault.configDir, "plugins", pluginId);
  const files = await safeListFiles(adapter, folder);
  const backupFiles = files.filter((p) => isBackupFileName(String(p).split("/").pop() || ""));
  if (!backupFiles.length) {
    const created = await createDataJsonBackupNow(plugin, "auto");
    if (created) await pruneDataJsonBackups(plugin, BACKUP_MAX_COUNT);
    return;
  }

  let newest = 0;
  for (const p of backupFiles) {
    const mtime = await safeStatMtime(adapter, String(p));
    if (mtime > newest) newest = mtime;
  }

  if (newest && now - newest < ROUTINE_BACKUP_MIN_INTERVAL_MS) return;

  const created = await createDataJsonBackupNow(plugin, "auto");
  if (created) await pruneDataJsonBackups(plugin, BACKUP_MAX_COUNT);
}
